from .smart_column_dataframe import SmartColumnDataFrame, read_csv

__version__ = '0.1.1'